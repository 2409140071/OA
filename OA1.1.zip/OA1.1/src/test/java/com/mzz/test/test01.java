package com.mzz.test;

/**
 * @Author MZZ
 * @Date 2019/12/10/0010 22:00
 * @Version 1.0
 **/
public class test01 {
    public static void main(String[] args) {
        String msg;
        int n=2;
        msg=(n>0?"添加成功":"添加失败");
        System.out.println(msg);
    }
}
